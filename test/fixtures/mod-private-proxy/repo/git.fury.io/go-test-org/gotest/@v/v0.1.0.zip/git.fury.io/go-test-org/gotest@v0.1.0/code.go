package gotest

import(
	"fmt"
)

func PrintHello() {
fmt.Println("hello")
}